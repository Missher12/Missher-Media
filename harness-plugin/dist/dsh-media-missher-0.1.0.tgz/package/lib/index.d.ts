import { ToolDefinition } from "@deepseek-ai/dsh-tools";
import { Context } from "@deepseek-ai/cordis";

//#region src/config.d.ts
declare const PLATFORMS: readonly ["bilibili", "xhs", "douyin", "weibo"];
type Platform = typeof PLATFORMS[number];
interface PluginConfigInput {
  defaultPlatforms?: string;
  defaultCount?: number;
  defaultXhsComments?: number;
  defaultAllowNavigation?: boolean;
  platformTimeoutSeconds?: number;
  executionTimeoutSeconds?: number;
  maxCount?: number;
  profilePath?: string;
  runtimeHome?: string;
  outputRoot?: string;
}
interface PluginConfig {
  defaultPlatforms: Platform[];
  defaultCount: number;
  defaultXhsComments: number;
  defaultAllowNavigation: boolean;
  platformTimeoutSeconds: number;
  executionTimeoutSeconds: number;
  maxCount: number;
  profilePath: string;
  runtimeHome: string;
  outputRoot: string;
}
interface CollectArgsInput {
  platforms?: string;
  count?: number;
  xhs_comments?: number;
  allow_navigation?: boolean;
}
interface CollectArgs {
  platforms: Platform[];
  platformText: string;
  count: number;
  xhsComments: number;
  allowNavigation: boolean;
}
/** Resolve and validate all deployment-varying plugin settings. */
declare function normalizePluginConfig(input: PluginConfigInput | undefined, dshHome: string, userHome?: string): PluginConfig;
/** Resolve a model request into one canonical, bounded collection request. */
declare function normalizeCollectArgs(input: CollectArgsInput, config: PluginConfig): CollectArgs;
//#endregion
//#region src/process.d.ts
interface ProcessOptions {
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  signal?: AbortSignal;
  timeoutMs?: number;
  maxOutputBytes?: number;
}
interface ProcessResult {
  code: number | null;
  signal: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
}
//#endregion
//#region src/runtime.d.ts
declare const EMBEDDED_VERSION = "15.2.1";
interface RuntimeLayout {
  python: string;
  payloadRoot: string;
}
interface RuntimeDependencies {
  payloadRoot?: string;
  platform?: NodeJS.Platform;
  installPython?: string;
  signal?: AbortSignal;
  processRunner?: (executable: string, args: readonly string[], options?: ProcessOptions) => Promise<ProcessResult>;
}
interface ControllerInvocation {
  executable: string;
  args: string[];
  env: NodeJS.ProcessEnv;
  cwd: string;
  timeoutMs: number;
}
interface ControllerSummary {
  status: 'success' | 'partial' | 'failed' | 'preflight-failed' | 'risk-stopped';
  runDirectory: string | null;
  evidence: string[];
}
interface RunEvidence {
  runDirectory: string;
  manifestPath: string;
  runStatus: string;
  records: Record<Platform, Record<string, unknown>[]>;
  platformStatuses: Record<Platform, string>;
  diagnostics: Record<Platform, {
    kind: string;
    code: string;
  }>;
  totalCollected: number;
}
/** Reuse or atomically provision the exact embedded Media runtime. */
declare function ensureRuntime(config: PluginConfig, dependencies?: RuntimeDependencies): Promise<RuntimeLayout>;
/** Build the exact existing-controller command for one bounded request. */
declare function buildControllerInvocation(config: PluginConfig, request: CollectArgs, runtime: RuntimeLayout): ControllerInvocation;
/** Parse the controller's single JSON summary without retaining private fields. */
declare function parseControllerSummary(stdout: string): ControllerSummary;
/** Load only fresh, manifest-declared platform JSON from the controller run. */
declare function loadRunEvidence(summary: ControllerSummary, config: PluginConfig): Promise<RunEvidence>;
//#endregion
//#region src/workbook.d.ts
interface WorkbookOptions {
  fileName?: string;
  generatedAt?: Date;
}
/** Project one validated private run into an atomic, mode-0600 XLSX workbook. */
declare function writeWorkbook(evidence: RunEvidence, request: CollectArgs, options?: WorkbookOptions): Promise<string>;
//#endregion
//#region src/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Context {
    dshHomePath(...segments: string[]): string;
  }
}
declare const name = "media-missher";
declare const inject: string[];
interface MediaToolDependencies {
  ensureRuntime?: (config: PluginConfig, dependencies: RuntimeDependencies) => ReturnType<typeof ensureRuntime>;
  processRunner?: (executable: string, args: readonly string[], options?: ProcessOptions) => Promise<ProcessResult>;
  loadRunEvidence?: typeof loadRunEvidence;
  writeWorkbook?: typeof writeWorkbook;
}
/** Create the model-facing tool with replaceable infrastructure for native smoke tests. */
declare function createMediaTool(config: PluginConfig, dependencies?: MediaToolDependencies): ToolDefinition;
/** Register the Bundle's one Agent tool and return its exact disposer. */
declare function registerMediaTool(ctx: Context, input?: PluginConfigInput, dependencies?: MediaToolDependencies): () => void;
/** Mount Media@Missher into the current Harness profile. */
declare function apply(ctx: Context, input?: PluginConfigInput): void;
declare const _default: {
  name: string;
  inject: string[];
  apply: typeof apply;
};
//#endregion
export { type CollectArgs, type CollectArgsInput, type ControllerInvocation, type ControllerSummary, type EMBEDDED_VERSION, MediaToolDependencies, type PLATFORMS, type Platform, type PluginConfig, type PluginConfigInput, type RunEvidence, type RuntimeDependencies, type RuntimeLayout, apply, type buildControllerInvocation, createMediaTool, _default as default, type ensureRuntime, inject, type loadRunEvidence, name, type normalizeCollectArgs, type normalizePluginConfig, type parseControllerSummary, registerMediaTool };