"""Backend selection and capability inspection for the two frozen backends.

One run owns exactly one browser backend:

``cdp``
    The long-lived backend. It attaches to the user's existing Chromium debug
    endpoint, so it requires an already running browser and never creates one.
``computer_use``
    Optional host-mediated control. A trusted adapter must prove scope,
    permissions, evidence and action guards before acquiring the run lease.

Selection priority is explicit request > saved profile preference > ``cdp``.
``auto`` is rejected outright: a failing backend may never be swapped for the
other one silently.

This module imports no browser library at all. Importing it (and
:mod:`media_missher_runtime.plan_runner`) must work on a machine with no
Playwright, no Chromium and no host computer-use adapter, so a capability or selection
question can always be answered before anything is launched.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .capabilities import (
    CAPABILITY_NAMES,
    CapabilityError,
    SUPPORT_ABSENT,
    backend_capability_matrix,
    evidence_level,
    require_task,
    support_level,
)
from .contracts import (
    BACKEND_COMPUTER_USE,
    BACKEND_CDP,
    BACKEND_SET,
    ContractError,
    normalize_backend,
)


class PreconditionLikeError(RuntimeError):
    """A fixed, model-safe precondition code that the CLI can print.

    It carries the code only. Messages, URLs, target identifiers and any other
    platform text stay out of it, so printing a diagnostic can never leak the
    private request that produced it.
    """

    def __init__(self, code: str) -> None:
        if not isinstance(code, str) or not code:
            raise ValueError("precondition code must be a non-empty string")
        self.code = code
        super().__init__(code)


#: Whether the backend requires exclusive host control for the whole lifecycle.
#: Neither backend creates a browser implicitly; CU owns only its bound lease.
OWNS_BROWSER: dict[str, bool] = {
    BACKEND_CDP: False,
    BACKEND_COMPUTER_USE: True,
}


def _plan_or_request_backend(source: object) -> object:
    """Read the explicit backend off a plan or a request without importing it."""

    if source is None:
        return None
    return getattr(source, "backend", None)


def backend_for(
    request_or_plan: object = None,
    profile: object = None,
    *,
    legacy_assist: object = None,
) -> str:
    """Resolve the frozen backend for one run.

    ``request_or_plan`` is the explicit choice for this run; ``profile`` is the
    saved preference (a profile mapping, or a plain string). A missing
    preference falls back to ``cdp``. Contract violations are re-raised as
    :class:`ValueError` so ordinary callers do not have to import the contract
    layer to catch them.
    """

    explicit = _plan_or_request_backend(request_or_plan)
    preference: object = profile
    if isinstance(profile, dict):
        preference = profile.get("backend")
    try:
        return normalize_backend(
            explicit, preference=preference, legacy_assist=legacy_assist
        )
    except ContractError as error:
        raise ValueError(str(error)) from error


@dataclass(frozen=True, slots=True)
class BackendBundle:
    """Everything the controller may assume about one backend up front."""

    name: str
    owns_browser: bool
    capabilities: tuple[dict[str, str], ...]

    def __post_init__(self) -> None:
        if self.name not in BACKEND_SET:
            raise ValueError("unsupported backend")

    @property
    def platforms(self) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(item["platform"] for item in self.capabilities)
        )

    def supported(self, platform: str, mode: str, capability: str) -> bool:
        return (
            support_level(self.name, platform, mode, capability) != SUPPORT_ABSENT
        )

    def evidence_level(self, platform: str, mode: str) -> str:
        return evidence_level(self.name, platform, mode)

    def to_json(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "owns_browser": self.owns_browser,
            "capabilities": [dict(item) for item in self.capabilities],
        }


def describe_backend(name: object) -> BackendBundle:
    """Describe one backend from the shared capability matrix."""

    if not isinstance(name, str) or name not in BACKEND_SET:
        raise ValueError("unsupported backend")
    return BackendBundle(
        name=name,
        owns_browser=OWNS_BROWSER[name],
        capabilities=backend_capability_matrix(name),
    )


def ensure_supported(backend: str, platform: str, mode: str) -> None:
    """Reject a task the frozen backend cannot execute at all.

    The capability matrix decides. A combination it does not support raises
    :class:`PreconditionLikeError` carrying the matrix's own fixed code, so the
    CLI prints ``kind=precondition`` instead of attempting an emulation.
    """

    try:
        require_task(backend, platform, mode)
    except CapabilityError as error:
        raise PreconditionLikeError(error.code) from error


def backend_matrix() -> tuple[BackendBundle, ...]:
    """Both backends, in the frozen declaration order."""

    return tuple(describe_backend(name) for name in (BACKEND_CDP, BACKEND_COMPUTER_USE))


def capability_names() -> tuple[str, ...]:
    return CAPABILITY_NAMES


def backend_names() -> tuple[str, ...]:
    return (BACKEND_CDP, BACKEND_COMPUTER_USE)


__all__ = [
    "BACKEND_COMPUTER_USE",
    "BACKEND_CDP",
    "BackendBundle",
    "OWNS_BROWSER",
    "PreconditionLikeError",
    "backend_for",
    "backend_matrix",
    "backend_names",
    "capability_names",
    "describe_backend",
    "ensure_supported",
]
