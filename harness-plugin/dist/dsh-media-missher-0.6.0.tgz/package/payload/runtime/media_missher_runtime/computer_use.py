"""Host-neutral observation boundary. A provenance label is not authentication."""
import hashlib
import json
import math
import struct
import re
import time
from datetime import datetime

BINDING_KEYS={'hostKind','hostInstanceId','sessionId','runId','targetIdentity','provider','schemaDigest','windowIdentity'}


def canonical(value, depth=0):
    if depth>16:raise ValueError('host-evidence-too-deep')
    if isinstance(value,float):
        if not math.isfinite(value):raise ValueError('host-evidence-invalid')
        if value.is_integer() and abs(value)>9007199254740991:raise ValueError('host-evidence-invalid')
        return int(value) if value.is_integer() else value
    if value is None or isinstance(value,(bool,str)):return value
    if isinstance(value,int):
        if abs(value)>9007199254740991:raise ValueError('host-evidence-invalid')
        return value
    if isinstance(value,list) and len(value)<=1000:return [canonical(item,depth+1) for item in value]
    if isinstance(value,dict) and len(value)<=256 and all(isinstance(k,str) and k not in {'__proto__','constructor','prototype'} for k in value):return {k:canonical(v,depth+1) for k,v in value.items()}
    raise ValueError('host-evidence-invalid')


def payload_digest(value):
    value=canonical(value)
    def tagged(item):
        if item is None:return ['null']
        if isinstance(item,str):
            if any(0xd800<=ord(ch)<=0xdfff for ch in item):raise ValueError('host-evidence-invalid')
            return ['string',item]
        if isinstance(item,bool):return ['boolean',item]
        if isinstance(item,(int,float)):return ['number',struct.pack('>d',0.0 if item==0 else float(item)).hex()]
        if isinstance(item,list):return ['array',[tagged(child) for child in item]]
        # Reject isolated surrogate keys before UTF-8 sorting, with the same
        # model-safe error as a surrogate value (and the TypeScript bridge).
        for key in item:tagged(key)
        return ['object',[[tagged(key),tagged(child)] for key,child in sorted(item.items(),key=lambda pair:pair[0].encode('utf-8'))]]
    payload=json.dumps(tagged(value),ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
    if len(payload)>4*1024*1024:raise ValueError('host-evidence-too-large')
    return hashlib.sha256(payload).hexdigest()


def validate_host_observation(value:dict,binding:dict,*,now=None,after=0)->dict:
    """Validate structure only; ingest must resolve a ref through a trusted bridge."""
    if not isinstance(binding,dict) or set(binding)!=BINDING_KEYS or any(not isinstance(v,str) or not v or len(v)>2048 or any(ord(c)<32 for c in v) for v in binding.values()):raise ValueError('host-binding-invalid')
    if not isinstance(value,dict) or set(value)!={'binding','callId','observationId','observedAt','source','provenance','evidenceRef','digestAlgorithm','contentDigest','payload'} or re.fullmatch(r'[A-Za-z0-9._:-]{1,128}',value.get('callId','')) is None:raise ValueError('host-evidence-invalid')
    if value.get('binding')!=binding:raise ValueError('host-binding-mismatch')
    if value.get('provenance')!='host-verified' or value.get('source') not in {'accessibility','visual'}:raise ValueError('host-evidence-unverified')
    if re.fullmatch(r'evidence-[A-Za-z0-9_-]{16,128}',value.get('evidenceRef','')) is None or re.fullmatch(r'[A-Za-z0-9._:-]{1,128}',value.get('observationId','')) is None:raise ValueError('host-evidence-invalid')
    try:observed=datetime.fromisoformat(value['observedAt'].replace('Z','+00:00')).timestamp()
    except (ValueError,KeyError,TypeError,AttributeError):raise ValueError('host-observation-stale') from None
    current=time.time() if now is None else now
    if observed<=after or observed>current+5 or current-observed>60:raise ValueError('host-observation-stale')
    if value.get('digestAlgorithm')!='media-canonical-v1':raise ValueError('host-digest-version-unsupported')
    if value.get('contentDigest')!=payload_digest(value.get('payload')):raise ValueError('host-evidence-digest-mismatch')
    return json.loads(json.dumps(value,ensure_ascii=False,allow_nan=False))


def can_start(capability):
    return isinstance(capability,dict) and capability.get('available') is True and capability.get('permission')=='granted' and capability.get('trustedEvidence') is True and capability.get('actionGuard') is True and capability.get('observation') in {'accessibility','visual','both'} and isinstance(capability.get('provider'),str) and re.fullmatch(r'[a-f0-9]{64}',capability.get('schemaDigest') or '') is not None


class ComputerUseStore:
    """Core lifecycle for a trusted host adapter, never a public raw-evidence ingest.

    The resolver is host code. Public model input only supplies an evidence ref.
    An absent resolver/capability refuses prepare without creating a run.
    """
    def __init__(self, root, runtime_home, *, resolve_evidence=None, clock=time.time):
        from pathlib import Path
        self.root=Path(root);self.runtime_home=Path(runtime_home)
        self.resolve_evidence=resolve_evidence;self.clock=clock

    @staticmethod
    def _scope(scope):
        if not isinstance(scope,dict) or set(scope)!={'hostKind','hostInstanceId','sessionId'} or any(not isinstance(v,str) or re.fullmatch(r'[A-Za-z0-9._:-]{1,128}',v) is None for v in scope.values()):raise ValueError('host-scope-invalid')
        return dict(scope)

    def _load(self,run_id,scope):
        from .batch_journal import read_private_json
        if re.fullmatch(r'run-[A-Za-z0-9._-]{1,128}',run_id or '') is None:raise ValueError('host-run-invalid')
        state=read_private_json(self.root/run_id/'host-state.json')
        if {key:state['binding'][key] for key in self._scope(scope)}!=scope:raise ValueError('host-binding-mismatch')
        return state

    def _save(self,state):
        from .batch_journal import atomic_json
        atomic_json(self.root/state['binding']['runId']/'host-state.json',state)

    @staticmethod
    def _owner(binding):return hashlib.sha256(json.dumps(binding,sort_keys=True).encode()).hexdigest()

    def prepare(self,plan,scope,capability,window_identity,*,max_actions=100):
        from .contracts import CollectionPlan
        from .storage import RunStore
        from .shared_safety import collection_lease,shared_directory
        from .batch_journal import atomic_json
        import secrets
        scope=self._scope(scope)
        if not can_start(capability) or self.resolve_evidence is None:raise ValueError('host-computer-use-unavailable')
        if not isinstance(plan,CollectionPlan) or plan.backend!='computer_use' or type(max_actions) is not int or not 1<=max_actions<=100 or not isinstance(window_identity,str) or not window_identity or len(window_identity)>256:raise ValueError('host-plan-invalid')
        # Do not accept a plan whose remaining targets or profile phase the
        # current core cannot execute. Admission precedes files and the lease.
        if len(plan.targets)!=1:raise ValueError('host-multi-target-unavailable')
        target=plan.targets[0]
        if target.platform!='x':raise ValueError('host-platform-parser-unavailable')
        if capability['observation']=='visual':raise ValueError('host-structured-observation-required')
        with collection_lease(self.runtime_home):
            self.root.mkdir(mode=0o700,parents=True,exist_ok=True)
            store=RunStore.create(self.root,secrets.token_hex(12))
            binding={**scope,'runId':store.path.name,'targetIdentity':plan.targets[0].identity,'provider':capability['provider'],'schemaDigest':capability['schemaDigest'],'windowIdentity':window_identity}
            state={'binding':binding,'plan':plan.to_json(),'status':'active','expires_at':self.clock()+min(600,plan.run_deadline_seconds),'actions':0,'max_actions':max_actions,'calls':[],'call_reservations':{},'settled_calls':[],'observation_ids':[],'last_observed':0,'last_observation_id':None,'needs_observation':True,'records':[],'sequence':0,'stop_reason':None}
            store.write_json('plan.json',plan.to_json());self._save(state)
            atomic_json(shared_directory()/'computer-use-lease.json',{'owner':self._owner(binding),'expires_at':state['expires_at']})
            return self._summary(state)

    def _active(self,state):
        if state['status']!='active':raise ValueError('host-run-not-active')
        if self.clock()>=state['expires_at']:raise ValueError('host-lease-expired')
        if state['actions']>=state['max_actions']:raise ValueError('host-action-budget')

    def reserve_action(self,run_id,scope,call_id,kind,window_identity,observation_id=None):
        from .shared_safety import collection_lease
        state=self._load(run_id,scope)
        with collection_lease(self.runtime_home,host_owner=self._owner(state['binding'])):
            state=self._load(run_id,scope);self._active(state)
            if kind not in {'observe','scroll','click','navigate'} or not isinstance(call_id,str) or not call_id or len(call_id)>128:raise ValueError('host-action-invalid')
            if window_identity!=state['binding']['windowIdentity']:raise ValueError('host-window-changed')
            if call_id in state['calls']:raise ValueError('host-action-already-dispatched')
            if kind!='observe' and (state['needs_observation'] or observation_id!=state['last_observation_id']):raise ValueError('host-observation-stale')
            if kind=='navigate' and not state['plan']['allow_navigation']:raise ValueError('host-navigation-not-authorized')
            # Persist before dispatch: timeout/cancel cannot refund or replay input.
            state['calls'].append(call_id);state['call_reservations'][call_id]={'kind':kind,'reserved_at':self.clock(),'window_identity':window_identity};state['actions']+=1;state['needs_observation']=True
            self._save(state)
            return {'allowed':True,'remaining_actions':state['max_actions']-state['actions']}

    def ingest(self,run_id,scope,evidence_ref):
        from .shared_safety import collection_lease,record_platform_risk
        from .batch_journal import BatchJournal,atomic_json
        state=self._load(run_id,scope)
        with collection_lease(self.runtime_home,state_only=True):
            state=self._load(run_id,scope)
            if self.resolve_evidence is None:raise ValueError('host-computer-use-unavailable')
            value=self.resolve_evidence(state['binding'],evidence_ref)
            observation=validate_host_observation(value,state['binding'],now=self.clock(),after=state['last_observed'])
            if observation['evidenceRef']!=evidence_ref or observation['observationId'] in state['observation_ids']:raise ValueError('host-evidence-replay')
            call_id=observation.get('callId')
            reservation=state['call_reservations'].get(call_id)
            if not reservation or call_id in state['settled_calls'] or reservation['window_identity']!=state['binding']['windowIdentity']:
                raise ValueError('host-result-not-dispatched')
            if self.clock()>state['expires_at']+60 or state['status']=='risk-stopped' or (state['status']!='active' and state['stop_reason'] not in {'cancelled','run-deadline'}):
                raise ValueError('host-result-window-expired')
            if reservation['kind']!='observe' and not (isinstance(observation['payload'],dict) and observation['payload'].get('risk') is True):raise ValueError('host-result-not-observation')
            if reservation['reserved_at']>state['expires_at']:raise ValueError('host-result-not-dispatched')
            state['settled_calls'].append(call_id)
            if self.clock()>=state['expires_at'] and state['stop_reason'] is None:state['stop_reason']='run-deadline'
            state['last_observed']=datetime.fromisoformat(observation['observedAt'].replace('Z','+00:00')).timestamp()
            state['last_observation_id']=observation['observationId'];state['observation_ids'].append(observation['observationId'])
            state['needs_observation']=False
            run=self.root/run_id
            atomic_json(run/f"observation-{len(state['observation_ids']):06d}.json",observation)
            if isinstance(observation['payload'],dict) and observation['payload'].get('risk') is True:
                state['stop_reason']='risk-stopped';record_platform_risk(state['binding']['targetIdentity'].split(':',1)[0],'risk-signal');atomic_json(run/'risk-marker.json',{'schema_version':1,'code':'risk-signal'})
                self._save(state)
                return self._finish_locked(state,'risk-stopped')
            from .contracts import CollectionPlan
            plan=CollectionPlan.from_json(state['plan'])
            target=next(t for t in plan.targets if t.identity==state['binding']['targetIdentity'])
            rows=normalize_host_payload(observation,target)
            from .best_effort import identity_of
            seen={identity_of(row,row['platform']) for row in state['records']}
            for row in rows:
                identity=identity_of(row,row['platform'])
                if identity is not None and identity not in seen:state['records'].append(row);seen.add(identity)
            state['sequence']+=1
            from .batch_journal import snapshot_projection
            projection=snapshot_projection(state['records'],plan,{target.identity:{'phase':'collecting','stop_reason':None}})
            BatchJournal(run).commit(state['sequence'],state['records'],{'manifest':projection,'binding':state['binding'],'backend':'computer_use','plan':state['plan'],'recovery':'reobserve-required','actions':state['actions']})
            self._save(state)
            if state['stop_reason'] in {'cancelled','run-deadline'}:return self._finish_locked(state,state['stop_reason'])
            return self._summary(state)

    def status(self,run_id,scope):return self._summary(self._load(run_id,scope))

    def finalize(self,run_id,scope):return self._finish(run_id,scope,None)
    def cancel(self,run_id,scope):return self._finish(run_id,scope,'cancelled')

    def _finish(self,run_id,scope,reason):
        from .shared_safety import collection_lease
        state=self._load(run_id,scope)
        with collection_lease(self.runtime_home,state_only=True):
            state=self._load(run_id,scope)
            if state['status']!='active':raise ValueError('host-run-not-active')
            if reason is None and set(state['calls'])-set(state['settled_calls']):
                raise ValueError('host-results-pending')
            if reason is None and self.clock()>=state['expires_at']:
                reason='run-deadline'
            return self._finish_locked(state,reason)

    def _finish_locked(self,state,reason):
        from .storage import RunStore
        from .contracts import CollectionPlan
        from .exporting import record_kind
        from .shared_safety import shared_directory
        from .batch_journal import atomic_json
        plan=CollectionPlan.from_json(state['plan']);store=RunStore(self.root/state['binding']['runId'])
        counts={p:sum(r['platform']==p for r in state['records']) for p in plan.platforms}
        kinds={}
        for row in state['records']:kind=record_kind(row);kinds[kind]=kinds.get(kind,0)+1
        enough=all(sum(r.get('target_identity')==t.identity and record_kind(r)=='posts' for r in state['records'])>=plan.count_for(t) for t in plan.targets)
        status='risk-stopped' if reason=='risk-stopped' else 'complete' if enough and reason is None else 'partial' if state['records'] else 'failed'
        statuses={p:'risk-stopped' if reason=='risk-stopped' else 'complete' if status=='complete' else 'shortfall' for p in plan.platforms}
        diagnostics={p:{'kind':'risk-stop','code':'risk-signal'} if reason=='risk-stopped' else {'kind':'ok','code':'ok'} if status=='complete' else {'kind':'result','code':'count-shortfall'} for p in plan.platforms}
        for p in plan.platforms:store.write_json(f'{p}.json',[r for r in state['records'] if r['platform']==p])
        store.write_manifest(counts=counts,paths={p:f'{p}.json' for p in plan.platforms},platforms=statuses,status=status,diagnostics=diagnostics,schema_version=3,backend='computer_use',record_kinds=kinds)
        store.commit_snapshot();store.write_json('run-result.json',{'schema':1,'status':'success' if status=='complete' else status})
        state['status']=status;state['stop_reason']=reason;self._save(state)
        from .batch_journal import read_private_json
        lease_path=shared_directory()/'computer-use-lease.json'
        lease=read_private_json(lease_path,65536)
        if lease.get('owner')==self._owner(state['binding']):
            pending=set(state['calls'])-set(state['settled_calls'])
            atomic_json(lease_path,{'owner':self._owner(state['binding']),'expires_at':state['expires_at'] if pending and reason=='cancelled' else 0})
        return self._summary(state)

    def _summary(self,state):
        return {'status':state['status'],'run_id':state['binding']['runId'],'binding':dict(state['binding']),'records':len(state['records']),'actions':state['actions'],'expires_at':state['expires_at'],'stop_reason':state['stop_reason']}


def normalize_host_payload(observation,target):
    """Deterministic mapping of adapter-verified semantic page observations.

    Raw pixels and agent-authored rows are not a structured parser output.
    """
    from .platforms import x,weibo_topic
    payload=observation['payload']
    if observation['source']!='accessibility' or not isinstance(payload,dict):raise ValueError('host-structured-observation-required')
    if target.platform=='x':
        rows=x.normalize_page_payload(payload,query=target.keyword,target_identity=target.identity,observed_at=observation['observedAt'],source_url=None,expected_handle=target.handle or target.uid if target.mode=='creator' else None,backend='computer_use')
    elif target.platform=='weibo' and target.mode=='topic':
        registry=weibo_topic.ParticipantRegistry()
        rows,_=weibo_topic.normalize_topic_payload(payload,topic=weibo_topic.parse_topic_input(target.topic),observed_at=observation['observedAt'],backend='computer_use',evidence_level='page',source_url=None,registry=registry)
        rows += list(registry.users.values()) + registry.relations
    else:
        raise ValueError('host-platform-parser-unavailable')
    for row in rows:
        row.update(backend='computer_use',evidence_level='page',observation_source=observation['source'],provenance='host-verified',provider=observation['binding']['provider'],observation_id=observation['observationId'],evidence_ref=observation['evidenceRef'],target_identity=target.identity)
    return rows
