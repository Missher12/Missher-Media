import { randomBytes } from 'node:crypto'
import {
  chmod,
  link,
  lstat,
  unlink,
} from 'node:fs/promises'
import { basename, join, resolve } from 'node:path'
import ExcelJS, { type Worksheet } from 'exceljs'
import type { CollectArgs, Platform } from './config.js'
import { PLATFORMS } from './config.js'
import type { RunEvidence } from './runtime.js'
import type { ProgressEvent } from './process.js'
import { formatPhaseTimings, parsePhaseTimings } from './progress.js'

export interface WorkbookOptions {
  phaseTimings?: ProgressEvent[]
  fileName?: string
  generatedAt?: Date
  priorCounts?: Partial<Record<Platform, number>>
}

const SHEET_NAMES: Record<Platform, string> = {
  bilibili: 'Bilibili',
  xhs: 'Xiaohongshu',
  douyin: 'Douyin',
  weibo: 'Weibo',
  x: 'X',
}

/** Non-post record kinds get their own worksheets so kinds are never mixed. */
const KIND_SHEET_NAMES: Record<string, string> = {
  posts: 'All Platforms',
  topic_participants: 'Topic Participants',
  user_profiles: 'User Profiles',
}

const IDENTIFIER_KEY = /(?:^|_)(?:id|ids|uid|uids)$|^(?:bvid|aweme_id|note_id|mblog_id|dynamic_id|native_id|tweet_id|author_id|conversation_id)$/iu
const FORMULA_PREFIX = /^[=+\-@]/u

function safeString(value: string): string {
  return FORMULA_PREFIX.test(value) ? `'${value}` : value
}

function cellValue(key: string, value: unknown): string | number | boolean | null {
  if (value === null || value === undefined) return null
  if (typeof value === 'string') return safeString(value)
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('workbook_non_finite_number')
    if (IDENTIFIER_KEY.test(key) && !Number.isSafeInteger(value)) throw new Error('workbook_unsafe_identifier')
    return IDENTIFIER_KEY.test(key) ? String(value) : value
  }
  if (typeof value === 'boolean') return value
  return safeString(JSON.stringify(value))
}

function columnsFor(records: readonly Record<string, unknown>[], includePlatform: boolean): string[] {
  const columns = includePlatform ? ['platform'] : []
  const seen = new Set(columns)
  for (const record of records) {
    for (const key of Object.keys(record)) {
      if (seen.has(key)) continue
      seen.add(key)
      columns.push(key)
    }
  }
  return columns.length === 0 ? ['platform'] : columns
}

/** Mirror the controller's record-kind classification for worksheet routing. */
function recordKindOf(record: Record<string, unknown>): string {
  const type = record.type
  if (type === 'user_profile' || type === 'profile') return 'user_profiles'
  if (type === 'topic_participant' || type === 'topic_participant_relation') return 'topic_participants'
  return 'posts'
}

function styleHeader(sheet: Worksheet): void {
  const header = sheet.getRow(1)
  header.font = { bold: true, color: { argb: 'FFFFFFFF' } }
  header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF385A7C' } }
  header.alignment = { vertical: 'middle', horizontal: 'center' }
  header.height = 22
  sheet.views = [{ state: 'frozen', ySplit: 1 }]
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: Math.max(1, sheet.columnCount) },
  }
  for (const column of sheet.columns) column.width = 18
}

function addRecordSheet(
  workbook: ExcelJS.Workbook,
  name: string,
  records: readonly Record<string, unknown>[],
  includePlatform: boolean,
): void {
  const sheet = workbook.addWorksheet(name)
  const columns = columnsFor(records, includePlatform)
  sheet.columns = columns.map(key => ({ header: key, key }))
  for (const record of records) {
    const row = Object.fromEntries(columns.map((key) => {
      const raw = key === 'platform' && record.platform === undefined
        ? name
        : record[key]
      return [key, cellValue(key, raw)]
    }))
    sheet.addRow(row)
  }
  styleHeader(sheet)
}

function safeFileName(requested: string | undefined, generatedAt: Date): string {
  if (requested !== undefined) {
    if (basename(requested) !== requested || !requested.endsWith('.xlsx')) {
      throw new Error('workbook_filename_invalid')
    }
    return requested
  }
  const timestamp = generatedAt.toISOString().replaceAll(/[-:.]/gu, '').replace('Z', 'Z')
  return `Media-Missher-全平台抓取结果-${timestamp}.xlsx`
}

/** Project one validated private run into an atomic, mode-0600 XLSX workbook. */
export async function writeWorkbook(
  evidence: RunEvidence,
  request: CollectArgs,
  options: WorkbookOptions = {},
): Promise<string> {
  const runDirectory = resolve(evidence.runDirectory)
  const directoryMetadata = await lstat(runDirectory)
  if (directoryMetadata.isSymbolicLink() || !directoryMetadata.isDirectory()) {
    throw new Error('workbook_run_directory_invalid')
  }
  if (process.platform !== 'win32') await chmod(runDirectory, 0o700)
  const timings = options.phaseTimings === undefined ? undefined : parsePhaseTimings(options.phaseTimings)
  const generatedAt = options.generatedAt ?? new Date()
  if (!Number.isFinite(generatedAt.getTime())) throw new Error('workbook_time_invalid')
  const fileName = safeFileName(options.fileName, generatedAt)
  const destination = join(runDirectory, fileName)
  const temporary = join(
    runDirectory,
    `.${fileName}.${randomBytes(8).toString('hex')}.tmp`,
  )

  const workbook = new ExcelJS.Workbook()
  workbook.creator = 'Media@Missher DeepSeek Harness Plugin'
  workbook.created = generatedAt
  workbook.modified = generatedAt
  const summary = workbook.addWorksheet('Summary')
  summary.columns = [
    { header: 'platform', key: 'platform' },
    { header: 'backend', key: 'backend' },
    { header: 'requested', key: 'requested' },
    { header: 'collected', key: 'collected' },
    { header: 'status', key: 'status' },
    { header: 'diagnostic_kind', key: 'diagnostic_kind' },
    { header: 'diagnostic_code', key: 'diagnostic_code' },
    { header: 'run_status', key: 'run_status' },
    { header: 'generated_at', key: 'generated_at' },
    ...(timings === undefined ? [] : [
      { header: 'platform_collection_ms', key: 'platform_collection_ms' },
      { header: 'controller_runtime_timings', key: 'controller_runtime_timings' },
    ]),
    ...(options.priorCounts === undefined ? [] : [
      { header: 'historical_accepted', key: 'historical_accepted' },
      { header: 'new_batch_target', key: 'new_batch_target' },
      { header: 'parent_run', key: 'parent_run' },
    ]),
  ]
  const selected = new Set(request.platforms)
  for (const platform of PLATFORMS) {
    summary.addRow({
      platform,
      backend: evidence.backend ?? 'cdp',
      requested: selected.has(platform) ? (request.countMode === 'best_effort' ? 0 : request.count) : 0,
      collected: evidence.records[platform].length,
      status: evidence.platformStatuses[platform],
      diagnostic_kind: evidence.diagnostics[platform].kind,
      diagnostic_code: evidence.diagnostics[platform].code,
      run_status: evidence.runStatus,
      generated_at: generatedAt.toISOString(),
      ...(timings === undefined ? {} : {
        platform_collection_ms: timings.find(event => event.phase === 'platform-collection' && event.platform === platform)?.duration_ms ?? null,
        controller_runtime_timings: formatPhaseTimings(timings),
      }),
      ...(options.priorCounts === undefined ? {} : {
        historical_accepted: options.priorCounts[platform] ?? 0,
        new_batch_target: selected.has(platform) ? Math.max(0, request.count - (options.priorCounts[platform] ?? 0)) : 0,
        parent_run: request.resumeRun ?? '',
      }),
    })
  }
  styleHeader(summary)

  const combined = PLATFORMS.flatMap(platform => evidence.records[platform].map(record => ({
    ...record,
    platform,
  })))
  addRecordSheet(workbook, 'All Platforms', combined, true)
  for (const platform of PLATFORMS) {
    addRecordSheet(workbook, SHEET_NAMES[platform], evidence.records[platform], false)
  }
  // Topic participation rows and user homepage rows are different entities from
  // posts, so they are projected onto their own worksheets.
  for (const kind of ['topic_participants', 'user_profiles'] as const) {
    const rows = combined.filter(record => recordKindOf(record) === kind)
    if (rows.length === 0) continue
    addRecordSheet(workbook, KIND_SHEET_NAMES[kind]!, rows, true)
  }

  try {
    await workbook.xlsx.writeFile(temporary)
    if (process.platform !== 'win32') await chmod(temporary, 0o600)
    await link(temporary, destination)
    await unlink(temporary)
    if (process.platform !== 'win32') await chmod(destination, 0o600)
    return resolve(destination)
  } finally {
    await unlink(temporary).catch((error: NodeJS.ErrnoException) => {
      if (error.code !== 'ENOENT') throw error
    })
  }
}
