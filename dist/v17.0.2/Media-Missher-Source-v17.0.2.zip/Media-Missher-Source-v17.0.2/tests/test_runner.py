import fcntl
import json
import os
import shlex
import shutil
import stat
import subprocess
import sys
import time
import venv
from pathlib import Path

import pytest

import media_missher_adapter as adapter

from media_missher_adapter import (
    CollectionRequest,
    ConfigurationError,
    build_engine_command,
    create_run_directory,
    discover_current_json,
    execute_engine,
    read_output,
    resolve_runtime_layout,
    run_collection_request,
)


def ok_preflight(*_args, **_kwargs):
    return {"status": "ok", "checks": {"synthetic": True}, "errors": []}


NESTED_RUNTIME_SOURCE = r'''#!/usr/bin/env python3
import argparse
import fcntl
import json
import os
import sys
import time
from pathlib import Path

PLATFORMS = ("bilibili", "xhs", "douyin", "weibo")

parser = argparse.ArgumentParser()
parser.add_argument("--count", "--max", dest="count", type=int, default=1)
parser.add_argument("--format", default="json")
parser.add_argument("--output", type=Path, required=False)
parser.add_argument("--platform")
parser.add_argument("--platform-timeout", type=float, default=300)
parser.add_argument("--xhs-comments", type=int, default=0)
parser.add_argument("--comments", type=int, default=0)
parser.add_argument("--complete", action="store_true")
parser.add_argument("--bilibili-complete", action="store_true")
parser.add_argument("--xhs-complete", action="store_true")
parser.add_argument("--no-feishu", action="store_true")
parser.add_argument("--allow-navigation", action="store_true")
parser.add_argument("--browser-assist", choices=("off", "browserskill"), default="off")
parser.add_argument("--screenshot-mode", choices=("off", "opened", "all"), default="off")
parser.add_argument("--cdp-url")
parser.add_argument("--search")
for platform in PLATFORMS:
    parser.add_argument(f"--{platform}-count", type=int)
    parser.add_argument(f"--{platform}-uid")
args = parser.parse_args()
mode = os.environ.get("MEDIA_MISSHER_FAKE_MODE", "ok")
if os.environ.get("MEDIA_MISSHER_REQUIRE_SHARED_LEASE") == "1":
    descriptor = os.open(
        Path(os.environ["MEDIA_MISSHER_HOME"]) / ".media-missher-install.lock",
        os.O_RDONLY,
    )
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            print("shared runtime lease was not held", file=sys.stderr)
            raise SystemExit(86)
    finally:
        os.close(descriptor)
if mode == "sleep":
    time.sleep(float(os.environ.get("MEDIA_MISSHER_FAKE_SLEEP", "5")))
if mode == "risk_wait":
    print("risk signal 471: synthetic stop", file=sys.stderr, flush=True)
    time.sleep(float(os.environ.get("MEDIA_MISSHER_FAKE_SLEEP", "5")))
if mode == "blocked_wait":
    print("account blocked: synthetic stop", file=sys.stderr, flush=True)
    time.sleep(float(os.environ.get("MEDIA_MISSHER_FAKE_SLEEP", "5")))
if mode == "benign_log":
    print("synthetic unlocked state", file=sys.stderr, flush=True)
if mode == "runtime_precondition":
    print("media-missher-diagnostic platform=xhs kind=precondition code=precondition-failed", file=sys.stderr, flush=True)
    raise SystemExit(78)
if mode.startswith("runtime_bsk_"):
    code = "bsk-" + mode.removeprefix("runtime_bsk_").replace("_", "-")
    print(f"media-missher-diagnostic platform=bilibili kind=precondition code={code}", file=sys.stderr, flush=True)
    raise SystemExit(78)
if mode == "forged_runtime_precondition":
    print("media-missher-diagnostic platform=xhs kind=precondition code=precondition-failed message=forged", file=sys.stderr, flush=True)
    raise SystemExit(78)

outer = args.output or Path.cwd()
outer.mkdir(parents=True, exist_ok=True)
inner = outer / f"run-{time.time_ns()}-synthetic"
inner.mkdir(mode=0o700)
(inner / "received_argv.txt").write_text(json.dumps(sys.argv[1:]), encoding="utf-8")
script_name = Path(sys.argv[0]).name
platforms = tuple((args.platform or ",".join(PLATFORMS)).split(",")) if script_name == "scrape_all.py" else (script_name.removeprefix("scrape_").removesuffix(".py"),)
paths = {}
counts = {}
statuses = {}
diagnostics = {}
for platform in platforms:
    requested = getattr(args, f"{platform}_count", None)
    count = requested if requested is not None else args.count
    count = max(1, count)
    cap = os.environ.get("MEDIA_MISSHER_FAKE_COUNT_CAP")
    if cap is not None:
        count = min(count, max(0, int(cap)))
    counts[platform] = count
    statuses[platform] = "complete"
    diagnostics[platform] = {"kind": "ok", "code": "ok"}
    records = [{
        "platform": platform,
        {"bilibili": "dynamic_id", "xhs": "note_id", "douyin": "aweme_id", "weibo": "mblog_id"}[platform]: f"synthetic-{platform}-{index}",
        "title": "synthetic title",
        "link": f"https://example.invalid/{platform}/{index}",
        "date": "2026-01-01",
        "liked": 1,
        "comments": 2,
        "shares": 3,
        "collected": 4,
    } for index in range(count)]
    if mode != "manifest_missing_data":
        artifact = inner / f"{platform}.json"
        artifact.write_text(json.dumps(records), encoding="utf-8")
        artifact.chmod(0o600)
        paths[platform] = artifact.name

if "xhs" in platforms:
    report = inner / "xhs_report.json"
    report.write_text(json.dumps({"status": "complete", "started_at": 1, "finished_at": 2, "final_items": counts["xhs"]}), encoding="utf-8")
    report.chmod(0o600)
    paths["xhs_report"] = report.name
    checkpoint = inner / "xhs_checkpoint.json"
    checkpoint.write_text(json.dumps({"items": [{"note_id": "synthetic-xhs-0", "observed_at": "2026-01-01T00:00:00Z"}]}), encoding="utf-8")
    checkpoint.chmod(0o600)
    paths["xhs_checkpoint"] = checkpoint.name

manifest_status = "risk-stopped" if mode == "manifest_risk" else "complete"
if mode == "manifest_risk":
    statuses[platforms[-1]] = "risk-stopped"
    diagnostics[platforms[-1]] = {"kind": "risk-stop", "code": "payload-471"}
if mode == "manifest_invalid_platform_status":
    statuses[platforms[-1]] = {}
manifest = inner / "manifest.json"
manifest.write_text(json.dumps({"counts": counts, "paths": paths, "platforms": statuses, "status": manifest_status, "diagnostics": diagnostics}), encoding="utf-8")
manifest.chmod(0o600)
print("synthetic collection complete")
if mode == "fail_after_empty_evidence":
    raise SystemExit(3)
raise SystemExit(75 if mode == "manifest_risk" else 0)
'''


def make_runtime_layout(fake_engine_root):
    home = fake_engine_root.parent / "runtime-home"
    shutil.copytree(fake_engine_root / "scripts", home / "current" / "scripts")
    (home / "current" / "VERSION").write_text("17.0.2\n", encoding="ascii")
    runtime_source = Path(__file__).resolve().parents[1] / "runtime"
    policy_package = home / "current" / "media_missher_runtime"
    policy_package.mkdir()
    for name in ("xhs_policy.py", "shared_safety.py", "progress.py"):
        shutil.copyfile(runtime_source / "media_missher_runtime" / name, policy_package / name)
    shutil.copyfile(runtime_source / "scripts" / "xhs_safety.py", home / "current" / "scripts" / "xhs_safety.py")
    interpreter = home / "venv" / "bin" / "python"
    interpreter.parent.mkdir(parents=True)
    interpreter.write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = \"-c\" ] && [ \"$2\" = \"import playwright\" ]; then exit 0; fi\n"
        f"exec {shlex.quote(str(Path(sys.executable).resolve()))} \"$@\"\n",
        encoding="utf-8",
    )
    interpreter.chmod(0o700)
    for script in (home / "current" / "scripts").glob("scrape_*.py"):
        script.write_text(NESTED_RUNTIME_SOURCE, encoding="utf-8")
    (home / "state").mkdir(mode=0o700)
    home.chmod(0o700)
    owner = home / ".media-missher-owner.json"
    owner.write_text(
        json.dumps({"name": "media-missher-runtime-home", "schema": 1}) + "\n",
        encoding="utf-8",
    )
    owner.chmod(0o600)
    lock = home / ".media-missher-install.lock"
    lock.touch(mode=0o600)
    lock.chmod(0o600)
    for root in (home / "current", home / "venv"):
        marker = root / ".media-missher-release"
        marker.write_text("test-release\n", encoding="ascii")
        marker.chmod(0o600)
    return resolve_runtime_layout(environ={"MEDIA_MISSHER_HOME": str(home)})


def test_run_directories_are_unique_and_private(tmp_path):
    first = create_run_directory(tmp_path)
    second = create_run_directory(tmp_path)
    assert first != second
    assert stat.S_IMODE(first.stat().st_mode) == 0o700
    assert stat.S_IMODE(second.stat().st_mode) == 0o700


def test_execute_engine_captures_evidence_and_never_creates_feishu(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    request = CollectionRequest(platforms=("bilibili", "xhs"), count=1)
    command = build_engine_command(request, run_dir, layout=layout)
    completed = execute_engine(command, timeout=5, run_dir=run_dir)
    assert completed.returncode == 0
    assert completed.timed_out is False
    assert completed.stdout_path.read_text(encoding="utf-8")
    assert not list(run_dir.glob("feishu_*"))
    received_path = next(run_dir.glob("run-*/received_argv.txt"))
    received = json.loads(received_path.read_text(encoding="utf-8"))
    assert "--no-feishu" in received


def test_execute_engine_accepts_forwarded_assist_modes(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    request = CollectionRequest(
        platforms=("bilibili",),
        count=1,
        platform_uids={"bilibili": "creator"},
        browser_assist="browserskill",
        screenshot_mode="opened",
        allow_navigation=True,
    )

    completed = execute_engine(
        build_engine_command(request, run_dir, layout=layout),
        timeout=5,
        run_dir=run_dir,
    )

    assert completed.returncode == 0
    received_path = next(run_dir.glob("run-*/received_argv.txt"))
    received = json.loads(received_path.read_text(encoding="utf-8"))
    assert received[received.index("--browser-assist") + 1] == "browserskill"
    assert received[received.index("--screenshot-mode") + 1] == "opened"


def test_execute_engine_creates_private_logs_before_child_start(
    fake_engine_root, tmp_path, monkeypatch
):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    command = build_engine_command(
        CollectionRequest(platforms=("bilibili",), count=1),
        run_dir,
        layout=layout,
    )
    observed_modes = {}
    real_popen = adapter.subprocess.Popen

    def inspect_log_modes(*args, **kwargs):
        for name in ("stdout.log", "stderr.log"):
            observed_modes[name] = stat.S_IMODE((run_dir / name).stat().st_mode)
        return real_popen(*args, **kwargs)

    monkeypatch.setattr(adapter.subprocess, "Popen", inspect_log_modes)
    previous_umask = os.umask(0o022)
    try:
        completed = execute_engine(command, timeout=5, run_dir=run_dir)
    finally:
        os.umask(previous_umask)

    assert completed.returncode == 0
    assert observed_modes == {"stdout.log": 0o600, "stderr.log": 0o600}


def test_execute_engine_closes_raw_descriptor_when_fdopen_fails(
    fake_engine_root, tmp_path, monkeypatch
):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    command = build_engine_command(
        CollectionRequest(platforms=("bilibili",), count=1),
        run_dir,
        layout=layout,
    )
    captured_descriptors = []

    def fail_fdopen(descriptor, *_args, **_kwargs):
        captured_descriptors.append(descriptor)
        raise RuntimeError("synthetic fdopen failure")

    monkeypatch.setattr(adapter.os, "fdopen", fail_fdopen)

    with pytest.raises(RuntimeError, match="synthetic fdopen failure"):
        execute_engine(command, timeout=5, run_dir=run_dir)

    assert len(captured_descriptors) == 1
    with pytest.raises(OSError):
        os.fstat(captured_descriptors[0])


@pytest.mark.parametrize("occupied_kind", ["file", "symlink"])
def test_execute_engine_refuses_occupied_log_paths(
    fake_engine_root, tmp_path, occupied_kind
):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    command = build_engine_command(
        CollectionRequest(platforms=("bilibili",), count=1),
        run_dir,
        layout=layout,
    )
    stdout_path = run_dir / "stdout.log"
    if occupied_kind == "file":
        protected_path = stdout_path
    else:
        protected_path = tmp_path / "protected.log"
        stdout_path.symlink_to(protected_path)
    protected_path.write_bytes(b"protected")

    with pytest.raises(FileExistsError):
        execute_engine(command, timeout=5, run_dir=run_dir)

    assert protected_path.read_bytes() == b"protected"
    assert not (run_dir / "stderr.log").exists()


def test_execute_engine_times_out_only_its_child(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    run_dir = create_run_directory(tmp_path)
    request = CollectionRequest(platforms=("bilibili",), count=1)
    command = build_engine_command(request, run_dir, layout=layout)
    command = command.with_environment(
        {"MEDIA_MISSHER_FAKE_MODE": "sleep", "MEDIA_MISSHER_FAKE_SLEEP": "5"}
    )
    completed = execute_engine(command, timeout=0.1, run_dir=run_dir)
    assert completed.timed_out is True
    assert completed.returncode is not None


def test_discover_current_json_rejects_stale_files(tmp_path):
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    stale = inner / "stale.json"
    stale.write_text("[]", encoding="utf-8")
    started_ns = tmp_path.stat().st_mtime_ns
    os.utime(stale, ns=(started_ns - 10_000, started_ns - 10_000))
    current = inner / "bilibili.json"
    current.write_text("[]", encoding="utf-8")
    manifest = inner / "manifest.json"
    manifest.write_text(
        json.dumps(
            {
                "counts": {"bilibili": 0},
                "paths": {"bilibili": current.name},
                "platforms": {"bilibili": "shortfall"},
                "status": "failed",
                "diagnostics": {
                    "bilibili": {"kind": "result", "code": "count-shortfall"}
                },
            }
        ),
        encoding="utf-8",
    )

    discovered = discover_current_json(tmp_path, started_ns=started_ns)

    assert current.resolve() in discovered
    assert manifest.resolve() in discovered
    assert stale.resolve() not in discovered


def test_discover_current_json_rejects_multiple_fresh_inner_runs(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    for name in ("run-one", "run-two"):
        inner = tmp_path / name
        inner.mkdir(mode=0o700)
        (inner / "manifest.json").write_text(
            json.dumps({"counts": {}, "paths": {}, "platforms": {}, "status": "failed"}),
            encoding="utf-8",
        )

    with __import__("pytest").raises(ConfigurationError, match="exactly one fresh runtime run"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_discover_current_json_rejects_single_run_legacy_four_key_manifest(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    artifact = inner / "bilibili.json"
    artifact.write_text("[]", encoding="utf-8")
    (inner / "manifest.json").write_text(
        json.dumps(
            {
                "counts": {"bilibili": 0},
                "paths": {"bilibili": "bilibili.json"},
                "platforms": {"bilibili": "complete"},
                "status": "complete",
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ConfigurationError, match="diagnostic contract"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_discover_current_json_rejects_unexpected_manifest_path_key(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    (inner / "unexpected.json").write_text("[]", encoding="utf-8")
    (inner / "manifest.json").write_text(
        json.dumps(
            {
                "counts": {"xhs": 1},
                "paths": {"unexpected": "unexpected.json"},
                "platforms": {"xhs": "complete"},
                "status": "complete",
                "diagnostics": {"xhs": {"kind": "ok", "code": "ok"}},
            }
        ),
        encoding="utf-8",
    )

    with __import__("pytest").raises(ConfigurationError, match="unexpected manifest path key"):
        discover_current_json(tmp_path, started_ns=started_ns)


@pytest.mark.parametrize(
    "diagnostics",
    [
        {},
        {"xhs": {"kind": "risk-stop", "code": "privateuid123"}},
        {"xhs": {"kind": "ok", "code": "ok", "reason": "private"}},
        {"weibo": {"kind": "ok", "code": "ok"}},
    ],
)
def test_discover_current_json_rejects_non_strict_diagnostics(
    tmp_path, diagnostics
):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    artifact = inner / "xhs.json"
    artifact.write_text("[]", encoding="utf-8")
    (inner / "manifest.json").write_text(
        json.dumps(
            {
                "counts": {"xhs": 0},
                "paths": {"xhs": "xhs.json"},
                "platforms": {"xhs": "complete"},
                "status": "complete",
                "diagnostics": diagnostics,
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ConfigurationError, match="diagnostic"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_discover_current_json_requires_path_for_completed_platform(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    (inner / "manifest.json").write_text(
        json.dumps(
            {
                "counts": {"xhs": 1},
                "paths": {},
                "platforms": {"xhs": "complete"},
                "status": "complete",
                "diagnostics": {"xhs": {"kind": "ok", "code": "ok"}},
            }
        ),
        encoding="utf-8",
    )

    with __import__("pytest").raises(ConfigurationError, match="completed platform path"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_discover_current_json_rejects_duplicate_manifest_keys(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    (inner / "manifest.json").write_text(
        '{"counts": {}, "counts": {}, "paths": {}, "platforms": {}, "status": "failed"}',
        encoding="utf-8",
    )

    with __import__("pytest").raises(ConfigurationError, match="duplicate key"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_discover_current_json_rejects_invalid_xhs_checkpoint(tmp_path):
    started_ns = tmp_path.stat().st_mtime_ns
    inner = tmp_path / "run-current"
    inner.mkdir(mode=0o700)
    (inner / "xhs.json").write_text("[]", encoding="utf-8")
    (inner / "xhs_checkpoint.json").write_text("{}", encoding="utf-8")
    (inner / "manifest.json").write_text(
        json.dumps(
            {
                "counts": {"xhs": 0},
                "paths": {
                    "xhs": "xhs.json",
                    "xhs_checkpoint": "xhs_checkpoint.json",
                },
                "platforms": {"xhs": "complete"},
                "status": "complete",
                "diagnostics": {"xhs": {"kind": "ok", "code": "ok"}},
            }
        ),
        encoding="utf-8",
    )

    with __import__("pytest").raises(ConfigurationError, match="checkpoint"):
        discover_current_json(tmp_path, started_ns=started_ns)


def test_run_collection_returns_success_with_current_evidence(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("douyin",),
            count=1,
            platform_uids={"douyin": "douyin-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
    )
    assert summary["status"] == "success"
    assert len(summary["evidence"]) == 1
    assert Path(summary["run_dir"]).is_dir()
    assert summary["validation"]["counts"] == {"douyin": 1}
    manifest_diagnostic = next(
        item
        for item in summary["validation"]["diagnostics"]
        if Path(item["path"]).name == "manifest.json"
    )
    assert manifest_diagnostic["platforms"] == {
        "douyin": {"kind": "ok", "code": "ok"}
    }


def test_run_collection_uses_filesystem_freshness_cutoff(
    fake_engine_root, tmp_path, monkeypatch
):
    layout = make_runtime_layout(fake_engine_root)
    monkeypatch.setattr(adapter.time, "time_ns", lambda: 2**63 - 1)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("douyin",),
            count=1,
            platform_uids={"douyin": "douyin-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
    )

    assert summary["status"] == "success"
    assert summary["validation"]["counts"] == {"douyin": 1}


def test_runtime_platform_precondition_maps_to_safe_preflight_summary(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "private-xhs"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "runtime_precondition"},
    )

    assert summary["status"] == "preflight-failed"
    assert summary["returncode"] == 78
    assert summary["diagnostics"] == {
        "xhs": {"kind": "precondition", "code": "precondition-failed"}
    }
    assert not [path for path in Path(summary["run_dir"]).glob("run-*") if path.is_dir()]
    encoded = json.dumps(summary)
    assert "private-xhs" not in encoded
    persisted_text = "\n".join(
        path.read_text(encoding="utf-8", errors="replace")
        for path in Path(summary["run_dir"]).rglob("*")
        if path.is_file()
    )
    assert "private-xhs" not in persisted_text


@pytest.mark.parametrize(
    "safe_code",
    (
        "bsk-missing",
        "bsk-unhealthy",
        "bsk-incompatible",
        "bsk-busy",
        "bsk-transport",
        "bsk-timeout",
        "bsk-target-ambiguous",
        "bsk-session-start",
        "bsk-tab-list",
        "bsk-tab-borrow",
        "bsk-snapshot",
        "bsk-click",
        "bsk-tab-return",
        "bsk-session-stop",
    ),
)
def test_runtime_browserskill_precondition_maps_to_safe_preflight_summary(
    safe_code, fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("bilibili",),
            count=1,
            platform_uids={"bilibili": "private-bilibili"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={
            "MEDIA_MISSHER_FAKE_MODE": "runtime_" + safe_code.replace("-", "_")
        },
    )

    assert summary["status"] == "preflight-failed"
    assert summary["returncode"] == 78
    assert summary["diagnostics"] == {
        "bilibili": {"kind": "precondition", "code": safe_code}
    }
    assert not [path for path in Path(summary["run_dir"]).glob("run-*") if path.is_dir()]


def test_forged_runtime_precondition_line_stays_failed_and_is_not_reflected(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "private-xhs"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={
            "MEDIA_MISSHER_FAKE_MODE": "forged_runtime_precondition"
        },
    )

    assert summary["status"] == "failed"
    assert summary.get("diagnostics", {}) == {}
    assert "message=forged" not in json.dumps(summary)


def test_run_collection_rejects_mixed_release_before_preflight_or_output(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)
    (layout.current / ".media-missher-release").write_text(
        "mixed-release\n", encoding="ascii"
    )
    preflight_called = False

    def preflight(*_args, **_kwargs):
        nonlocal preflight_called
        preflight_called = True
        return ok_preflight()

    summary = run_collection_request(
        CollectionRequest(
            platforms=("douyin",),
            count=1,
            platform_uids={"douyin": "douyin-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=preflight,
        execution_timeout=5,
    )

    assert summary["status"] == "preflight-failed"
    assert summary["run_dir"] is None
    assert summary["preflight"]["checks"] == {
        "runtime_lease": True,
        "release": False,
    }
    assert preflight_called is False
    assert not list(tmp_path.glob("run-*"))
    assert any("release" in error.lower() for error in summary["errors"])


def test_run_collection_holds_lease_through_child_and_validation(
    fake_engine_root, tmp_path, monkeypatch
):
    layout = make_runtime_layout(fake_engine_root)
    lock = layout.home / ".media-missher-install.lock"
    real_validate = adapter.validate_run
    validation_saw_lease = False

    def validate_while_locked(paths, request, started_ns):
        nonlocal validation_saw_lease
        descriptor = os.open(lock, os.O_RDONLY)
        try:
            with pytest.raises(BlockingIOError):
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            validation_saw_lease = True
        finally:
            os.close(descriptor)
        return real_validate(paths, request, started_ns)

    monkeypatch.setattr(adapter, "validate_run", validate_while_locked)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "weibo-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_REQUIRE_SHARED_LEASE": "1"},
    )

    assert summary["status"] == "success"
    assert validation_saw_lease is True


def test_run_collection_rejects_a_concurrent_collection_before_preflight_or_output(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)
    lock = layout.home / ".media-missher-collection.lock"
    lock.touch(mode=0o600)
    lock.chmod(0o600)
    descriptor = os.open(lock, os.O_RDWR)
    preflight_called = False

    def preflight(*_args, **_kwargs):
        nonlocal preflight_called
        preflight_called = True
        return ok_preflight()

    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        summary = run_collection_request(
            CollectionRequest(
                platforms=("xhs",),
                count=1,
                platform_uids={"xhs": "private-xhs"},
            ),
            layout=layout,
            data_root=tmp_path,
            preflight_runner=preflight,
            execution_timeout=5,
        )
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)

    assert summary["status"] == "preflight-failed"
    assert summary["run_dir"] is None
    assert summary["preflight"]["checks"] == {
        "runtime_lease": True,
        "release": True,
        "collection_lease": False,
    }
    assert preflight_called is False
    assert not list(tmp_path.glob("run-*"))


@pytest.mark.parametrize("marker", ["latched", "invalid"])
def test_collection_reports_risk_latch_without_reclassifying_valid_state(
    fake_engine_root, tmp_path, marker
):
    from media_missher_runtime.shared_safety import collection_lease, record_platform_risk, shared_directory

    layout = make_runtime_layout(fake_engine_root)
    with collection_lease(layout.home, state_only=True):
        record_platform_risk("xhs", "challenge")
    path = shared_directory() / "platform-risk.json"
    if marker == "invalid":
        path.write_text("invalid json\n")
    before = path.read_bytes()

    def unexpected(*_args, **_kwargs):
        pytest.fail("risk state must stop before platform preflight or collection")

    summary = run_collection_request(
        CollectionRequest(platforms=("xhs",), count=1, platform_uids={"xhs": "synthetic"}),
        layout=layout, data_root=tmp_path / "output", preflight_runner=unexpected,
    )
    assert summary["status"] == "preflight-failed"
    assert summary["preflight"]["code"] == ("platform-risk-latched" if marker == "latched" else "shared-state-invalid")
    assert summary["preflight"]["checks"]["collection_lease"] is False
    assert summary["run_dir"] is None
    assert not (tmp_path / "output").exists()
    assert path.read_bytes() == before


def test_collection_business_oserror_is_not_reclassified_as_lease_failure(
    fake_engine_root, tmp_path, monkeypatch
):
    layout = make_runtime_layout(fake_engine_root)
    failure = OSError("synthetic evidence read failure")

    def fail_validation(*_args, **_kwargs):
        raise failure

    monkeypatch.setattr(adapter, "validate_run", fail_validation)

    with pytest.raises(OSError, match="synthetic evidence read failure") as raised:
        run_collection_request(
            CollectionRequest(
                platforms=("weibo",),
                count=1,
                platform_uids={"weibo": "weibo-user"},
            ),
            layout=layout,
            data_root=tmp_path,
            preflight_runner=ok_preflight,
            execution_timeout=5,
        )

    assert raised.value is failure
    assert len(list(tmp_path.glob("run-*"))) == 1
    descriptor = os.open(layout.home / ".media-missher-install.lock", os.O_RDONLY)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(descriptor, fcntl.LOCK_UN)
    finally:
        os.close(descriptor)


def test_run_collection_converts_only_after_validation(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "weibo-user"},
            output_format="csv",
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
    )
    assert summary["status"] == "success"
    assert len(summary["outputs"]) == 1
    converted = Path(summary["outputs"][0])
    assert converted.suffix == ".csv"
    assert len(read_output(converted, "csv")) == 1
    assert not list(Path(summary["run_dir"]).glob("feishu_*"))


def test_run_collection_uses_validated_count_for_partial_status(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("bilibili",),
            count=2,
            platform_uids={"bilibili": "bilibili-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_COUNT_CAP": "1"},
    )
    assert summary["status"] == "partial"
    assert summary["validation"]["counts"] == {"bilibili": 1}


def test_failed_engine_with_only_empty_evidence_is_failed(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("bilibili",),
            count=1,
            platform_uids={"bilibili": "bilibili-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={
            "MEDIA_MISSHER_FAKE_COUNT_CAP": "0",
            "MEDIA_MISSHER_FAKE_MODE": "fail_after_empty_evidence",
        },
    )

    assert summary["status"] == "failed"
    assert summary["returncode"] == 3
    assert summary["validation"]["counts"] == {"bilibili": 0}


def test_run_collection_classifies_risk_and_stops(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "risk_wait"},
    )
    assert summary["status"] == "risk-stopped"
    assert summary["evidence"] == []
    assert summary["timed_out"] is False
    assert summary["duration_seconds"] < 4


def test_run_collection_classifies_blocked_and_stops(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "blocked_wait"},
    )
    assert summary["status"] == "risk-stopped"
    assert summary["evidence"] == []
    assert summary["timed_out"] is False
    assert summary["duration_seconds"] < 4


def test_run_collection_does_not_treat_unlocked_as_a_risk_signal(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "benign_log"},
    )
    assert summary["status"] == "success"
    assert summary["validation"]["counts"] == {"xhs": 1}


def test_run_collection_stops_before_directory_when_preflight_fails(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    summary = run_collection_request(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "weibo-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=lambda *_args, **_kwargs: {
            "status": "failed",
            "checks": {"cdp": False},
            "errors": ["CDP unavailable"],
        },
    )
    assert summary["status"] == "preflight-failed"
    assert summary["run_dir"] is None
    assert not list(tmp_path.glob("run-*"))


def test_run_collection_returns_structured_failure_when_engine_disappears(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    layout.python.unlink()
    summary = run_collection_request(
        CollectionRequest(
            platforms=("bilibili",),
            count=1,
            platform_uids={"bilibili": "bilibili-user"},
        ),
        layout=layout,
        data_root=tmp_path / "runs",
        preflight_runner=ok_preflight,
    )
    assert summary["status"] == "failed"
    assert summary["evidence"] == []
    assert any("python" in error for error in summary["errors"])


def test_engine_command_uses_absolute_shared_runtime_paths(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)

    command = build_engine_command(
        CollectionRequest(
            platforms=("bilibili", "xhs"),
            count=2,
            platform_uids={"bilibili": "bilibili-user", "xhs": "xhs-user"},
            xhs_complete=True,
        ),
        tmp_path,
        layout=layout,
    )

    assert command.script == (layout.current / "scripts" / "scrape_all.py")
    assert command.argv[:2] == (str(layout.python), str(command.script))
    assert all(Path(value).is_absolute() for value in command.argv[:2])
    assert command.environment["MEDIA_MISSHER_HOME"] == str(layout.home)
    assert "--platform" in command.argv
    assert "--xhs-complete" in command.argv
    assert "--no-feishu" in command.argv


def test_engine_command_preserves_real_venv_interpreter_identity(tmp_path):
    home = tmp_path / "runtime-home"
    scripts = home / "current" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "scrape_all.py").write_text(
        "raise SystemExit(0)\n", encoding="utf-8"
    )
    venv.EnvBuilder(with_pip=False, symlinks=True).create(home / "venv")
    layout = resolve_runtime_layout(environ={"MEDIA_MISSHER_HOME": str(home)})
    assert layout.python.is_symlink()

    command = build_engine_command(
        CollectionRequest(
            platforms=("bilibili",),
            count=1,
            platform_uids={"bilibili": "bilibili-user"},
        ),
        tmp_path / "staging",
        layout=layout,
    )
    identity = subprocess.run(
        [command.argv[0], "-c", "import sys; print(sys.prefix)"],
        check=True,
        capture_output=True,
        text=True,
    )

    assert Path(identity.stdout.strip()).resolve() == (home / "venv").resolve()
    assert command.argv[0] == str(layout.python)


def test_engine_command_forwards_exact_cdp_and_only_explicit_navigation(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)
    passive = build_engine_command(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "creator"},
        ),
        tmp_path,
        layout=layout,
        cdp_url="http://127.0.0.1:9333",
    )
    authorized = build_engine_command(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "creator"},
            allow_navigation=True,
        ),
        tmp_path,
        layout=layout,
        cdp_url="http://127.0.0.1:9444",
    )

    assert passive.argv[passive.argv.index("--cdp-url") + 1] == "http://127.0.0.1:9333"
    assert "--allow-navigation" not in passive.argv
    assert authorized.argv[authorized.argv.index("--cdp-url") + 1] == "http://127.0.0.1:9444"
    assert "--allow-navigation" in authorized.argv


def test_creator_without_uid_fails_before_preflight_or_output(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    preflight_called = False

    def preflight(*_args, **_kwargs):
        nonlocal preflight_called
        preflight_called = True
        return ok_preflight()

    summary = run_collection_request(
        CollectionRequest(platforms=("weibo",), count=1),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=preflight,
    )

    assert summary["status"] == "preflight-failed"
    assert summary["run_dir"] is None
    assert preflight_called is False
    assert not list(tmp_path.glob("run-*"))
    assert any("UID" in error for error in summary["errors"])


def test_search_without_uid_still_reaches_preflight(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)
    preflight_called = False

    def preflight(*_args, **_kwargs):
        nonlocal preflight_called
        preflight_called = True
        return {"status": "failed", "checks": {}, "errors": ["synthetic"]}

    summary = run_collection_request(
        CollectionRequest(platforms=("weibo",), count=1, search="topic"),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=preflight,
    )

    assert summary["status"] == "preflight-failed"
    assert preflight_called is True
    assert not list(tmp_path.glob("run-*"))


def test_nested_runtime_manifest_and_complete_xhs_report_are_diagnostics(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
    )

    assert summary["status"] == "success"
    assert [Path(path).name for path in summary["evidence"]] == ["xhs.json"]
    assert {item["status"] for item in summary["validation"]["diagnostics"]} == {
        "complete"
    }


def test_manifest_cannot_replace_missing_platform_data(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "manifest_missing_data"},
    )

    assert summary["status"] == "failed"
    assert summary["evidence"] == []
    assert summary["validation"]["counts"] == {"xhs": 0}


def test_manifest_risk_status_wins_over_partial_platform_data(fake_engine_root, tmp_path):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("xhs",),
            count=1,
            platform_uids={"xhs": "xhs-user"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={"MEDIA_MISSHER_FAKE_MODE": "manifest_risk"},
    )

    assert summary["status"] == "risk-stopped"
    assert [Path(path).name for path in summary["evidence"]] == ["xhs.json"]


def test_malformed_manifest_platform_status_returns_structured_failure(
    fake_engine_root, tmp_path
):
    layout = make_runtime_layout(fake_engine_root)

    summary = run_collection_request(
        CollectionRequest(
            platforms=("weibo",),
            count=1,
            platform_uids={"weibo": "creator"},
        ),
        layout=layout,
        data_root=tmp_path,
        preflight_runner=ok_preflight,
        execution_timeout=5,
        command_environment={
            "MEDIA_MISSHER_FAKE_MODE": "manifest_invalid_platform_status"
        },
    )

    assert summary["status"] == "failed"
    assert any("diagnostic" in error for error in summary["errors"])
